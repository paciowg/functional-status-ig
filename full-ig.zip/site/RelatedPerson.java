package http://hl7.org/fhir/us/PACIO-functional-cognitive-status/ImplementationGuide/hl7.fhir.us.PACIO-functional-status-0.1.0;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class RelatedPerson {

}
